/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package arvore;

/**
 *
 * @author 10361
 */
public class Nodo {
    private Item item;
    private Nodo esq;
    private Nodo dir;
}
